import { useEffect, useRef, useState } from "react";
import { Mic, MicOff, Volume2 } from "lucide-react";
import { Button } from "./ui/button";

// 🎨 COLOR CONFIGURATION - Easy to change!
const COLORS = {
  primary: "#8B5CF6", // Vibrant blue
  secondary: "#FFFFFF", // Cyan
  accent: "#8B5CF6", // Purple
  highlight: "#8B5CF6", // Pink
  background: "#000000", // Black background
};

interface GradientBlob {
  x: number;
  y: number;
  radius: number;
  color: string;
  vx: number;
  vy: number;
  targetX: number;
  targetY: number;
  pulsePhase: number;
  pulseSpeed: number;
  orbitRadius: number;
  orbitAngle: number;
  orbitSpeed: number;
}

export function VoiceAssistant() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [error, setError] = useState<string>("");
  const [
    speechRecognitionAvailable,
    setSpeechRecognitionAvailable,
  ] = useState(true);
  const recognitionRef = useRef<any>(null);
  const animationRef = useRef<number>();
  const blobsRef = useRef<GradientBlob[]>([]);
  const audioAnalyzerRef = useRef<AnalyserNode | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const speakingTimeRef = useRef<number>(0);
  const currentCircleRadiusRef = useRef<number>(120); // For smooth animation

  // Initialize gradient blobs
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    blobsRef.current = [
      // Central blob for base coverage - pulsing
      {
        x: centerX,
        y: centerY,
        radius: 150,
        color: COLORS.primary,
        vx: 0,
        vy: 0,
        targetX: centerX,
        targetY: centerY,
        pulsePhase: 0,
        pulseSpeed: 0.04,
        orbitRadius: 0,
        orbitAngle: 0,
        orbitSpeed: 0,
      },
      // Distributed blobs in cardinal directions
      {
        x: centerX,
        y: centerY,
        radius: 140,
        color: COLORS.secondary,
        vx: 0,
        vy: 0,
        targetX: centerX,
        targetY: centerY,
        pulsePhase: 0,
        pulseSpeed: 0.05,
        orbitRadius: 70,
        orbitAngle: 0,
        orbitSpeed: 0.025,
      },
      {
        x: centerX,
        y: centerY,
        radius: 130,
        color: COLORS.accent,
        vx: 0,
        vy: 0,
        targetX: centerX,
        targetY: centerY,
        pulsePhase: Math.PI / 4,
        pulseSpeed: 0.045,
        orbitRadius: 75,
        orbitAngle: Math.PI / 2,
        orbitSpeed: 0.02,
      },
      {
        x: centerX,
        y: centerY,
        radius: 135,
        color: COLORS.highlight,
        vx: 0,
        vy: 0,
        targetX: centerX,
        targetY: centerY,
        pulsePhase: Math.PI / 2,
        pulseSpeed: 0.055,
        orbitRadius: 65,
        orbitAngle: Math.PI,
        orbitSpeed: 0.03,
      },
      {
        x: centerX,
        y: centerY,
        radius: 125,
        color: COLORS.primary,
        vx: 0,
        vy: 0,
        targetX: centerX,
        targetY: centerY,
        pulsePhase: Math.PI,
        pulseSpeed: 0.042,
        orbitRadius: 80,
        orbitAngle: Math.PI * 1.5,
        orbitSpeed: 0.028,
      },
      {
        x: centerX,
        y: centerY,
        radius: 120,
        color: COLORS.secondary,
        vx: 0,
        vy: 0,
        targetX: centerX,
        targetY: centerY,
        pulsePhase: Math.PI * 1.25,
        pulseSpeed: 0.048,
        orbitRadius: 70,
        orbitAngle: Math.PI / 4,
        orbitSpeed: 0.022,
      },
      {
        x: centerX,
        y: centerY,
        radius: 130,
        color: COLORS.accent,
        vx: 0,
        vy: 0,
        targetX: centerX,
        targetY: centerY,
        pulsePhase: Math.PI * 1.5,
        pulseSpeed: 0.052,
        orbitRadius: 75,
        orbitAngle: Math.PI * 1.75,
        orbitSpeed: 0.026,
      },
      {
        x: centerX,
        y: centerY,
        radius: 115,
        color: COLORS.highlight,
        vx: 0,
        vy: 0,
        targetX: centerX,
        targetY: centerY,
        pulsePhase: Math.PI * 1.75,
        pulseSpeed: 0.058,
        orbitRadius: 68,
        orbitAngle: Math.PI * 0.75,
        orbitSpeed: 0.024,
      },
    ];
  }, []);

  // Animation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    // Dynamic circle sizes for different states
    const idleRadius = 120;
    const listeningRadius = 130;
    const speakingRadius = 135;

    const animate = () => {
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Fill with background color
      ctx.fillStyle = COLORS.background;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Determine target radius based on state
      let targetRadius = idleRadius;
      if (isSpeaking) {
        const time = Date.now() * 0.001;
        const pulse = Math.sin(time * 4) * 0.5 + 0.5;
        targetRadius = speakingRadius + pulse * 5;
      } else if (isListening) {
        targetRadius = listeningRadius;
      }

      // Smoothly animate to target radius
      currentCircleRadiusRef.current +=
        (targetRadius - currentCircleRadiusRef.current) * 0.1;

      // Save the context state
      ctx.save();

      // Create circular clipping path to contain all gradients
      ctx.beginPath();
      ctx.arc(
        centerX,
        centerY,
        currentCircleRadiusRef.current,
        0,
        Math.PI * 2,
      );
      ctx.clip();

      // Get audio data if speaking
      let audioIntensity = 0;
      if (isSpeaking && audioAnalyzerRef.current) {
        const dataArray = new Uint8Array(
          audioAnalyzerRef.current.frequencyBinCount,
        );
        audioAnalyzerRef.current.getByteFrequencyData(
          dataArray,
        );
        const average =
          dataArray.reduce((a, b) => a + b, 0) /
          dataArray.length;
        audioIntensity = average / 255;
      }

      blobsRef.current.forEach((blob, index) => {
        // Update pulse phase
        blob.pulsePhase += blob.pulseSpeed;

        if (isSpeaking) {
          // Speaking: dramatic radial pulsing from center
          const time = Date.now() * 0.001;
          // Simulate audio intensity with wave patterns
          const simAudioIntensity =
            (Math.sin(time * 4 + index * 1.5) * 0.5 + 0.5) *
            (Math.cos(time * 6 + index * 2) * 0.3 + 0.7);

          // Central blob pulsing radius
          if (index === 0) {
            blob.targetX = centerX;
            blob.targetY = centerY;
          } else {
            // Fixed angle for each blob (no circular orbit)
            // Blobs push out radially from center based on audio
            const baseAngle = blob.orbitAngle; // Keep initial angle fixed

            // Dramatic radial pulsing: blobs pulse in and out from center
            const radialPulse =
              blob.orbitRadius * (0.3 + simAudioIntensity * 1.2);

            // Add quick vibration/jitter for more dynamic feel
            const jitter =
              Math.sin(time * 12 + index) *
              15 *
              simAudioIntensity;

            blob.targetX =
              centerX +
              Math.cos(baseAngle) * (radialPulse + jitter);
            blob.targetY =
              centerY +
              Math.sin(baseAngle) * (radialPulse + jitter);
          }

          // Dramatic radius changes to simulate sound waves
          const radiusBoost = 1 + simAudioIntensity * 0.5 + Math.sin(blob.pulsePhase) * 0.2;
          const currentRadius = blob.radius * radiusBoost;

          // Very responsive movement for vibration effect
          blob.x += (blob.targetX - blob.x) * 0.35;
          blob.y += (blob.targetY - blob.y) * 0.35;

          // Draw blob with more opaque gradients for complete coverage
          const gradient = ctx.createRadialGradient(
            blob.x,
            blob.y,
            0,
            blob.x,
            blob.y,
            currentRadius,
          );
          gradient.addColorStop(0, blob.color + "FF");
          gradient.addColorStop(0.3, blob.color + "CC");
          gradient.addColorStop(0.7, blob.color + "66");
          gradient.addColorStop(1, blob.color + "00");

          ctx.fillStyle = gradient;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        } else if (isListening) {
          // Central blob stays at center with pulsing radius
          if (index === 0) {
            blob.targetX = centerX;
            blob.targetY = centerY;
          } else {
            // Listening: gentle radial breathing from center
            blob.orbitAngle += blob.orbitSpeed * 0.8;

            const radialDistance =
              blob.orbitRadius * (0.6 + Math.sin(blob.pulsePhase * 2) * 0.35);
            blob.targetX =
              centerX + Math.cos(blob.orbitAngle) * radialDistance;
            blob.targetY =
              centerY + Math.sin(blob.orbitAngle) * radialDistance;
          }

          blob.x += (blob.targetX - blob.x) * 0.15;
          blob.y += (blob.targetY - blob.y) * 0.15;

          // Pulsing radius
          const radiusBoost = 1 + Math.sin(blob.pulsePhase) * 0.15;
          const currentRadius = blob.radius * radiusBoost;

          const gradient = ctx.createRadialGradient(
            blob.x,
            blob.y,
            0,
            blob.x,
            blob.y,
            currentRadius,
          );
          gradient.addColorStop(0, blob.color + "FF");
          gradient.addColorStop(0.3, blob.color + "DD");
          gradient.addColorStop(0.7, blob.color + "77");
          gradient.addColorStop(1, blob.color + "00");

          ctx.fillStyle = gradient;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        } else {
          // Central blob stays at center with subtle pulse
          if (index === 0) {
            blob.targetX = centerX;
            blob.targetY = centerY;
          } else {
            // Idle: subtle radial breathing from center
            blob.orbitAngle += blob.orbitSpeed * 0.5;

            const radialDistance =
              blob.orbitRadius * (0.5 + Math.sin(blob.pulsePhase) * 0.3);
            blob.targetX =
              centerX + Math.cos(blob.orbitAngle) * radialDistance;
            blob.targetY =
              centerY + Math.sin(blob.orbitAngle) * radialDistance;
          }

          blob.x += (blob.targetX - blob.x) * 0.08;
          blob.y += (blob.targetY - blob.y) * 0.08;

          // Pulsing radius
          const radiusBoost = 1 + Math.sin(blob.pulsePhase) * 0.1;
          const currentRadius = blob.radius * radiusBoost;

          const gradient = ctx.createRadialGradient(
            blob.x,
            blob.y,
            0,
            blob.x,
            blob.y,
            currentRadius,
          );
          gradient.addColorStop(0, blob.color + "FF");
          gradient.addColorStop(0.3, blob.color + "DD");
          gradient.addColorStop(0.7, blob.color + "66");
          gradient.addColorStop(1, blob.color + "00");

          ctx.fillStyle = gradient;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
      });

      // Apply blur for smooth gradient mesh effect
      ctx.filter = "blur(40px)";
      ctx.drawImage(canvas, 0, 0);
      ctx.filter = "none";

      // Restore context to remove clipping
      ctx.restore();

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isListening, isSpeaking]);

  // Initialize speech recognition
  useEffect(() => {
    if (
      "webkitSpeechRecognition" in window ||
      "SpeechRecognition" in window
    ) {
      const SpeechRecognition =
        (window as any).SpeechRecognition ||
        (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;

      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0])
          .map((result) => result.transcript)
          .join("");
        setTranscript(transcript);
      };

      recognition.onerror = (event: any) => {
        console.error("Speech recognition error:", event.error);

        if (event.error === "not-allowed") {
          setError(
            "Microphone access denied. Please allow microphone access in your browser settings.",
          );
        } else if (event.error === "no-speech") {
          setError("No speech detected. Please try again.");
        } else {
          setError(`Speech recognition error: ${event.error}`);
        }

        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    } else {
      setSpeechRecognitionAvailable(false);
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      if (!speechRecognitionAvailable) {
        setError(
          "Speech recognition is not available in your browser.",
        );
        return;
      }

      setError("");
      setTranscript("");
      try {
        recognitionRef.current?.start();
        setIsListening(true);
      } catch (err) {
        setError(
          "Failed to start speech recognition. Please check your microphone permissions.",
        );
        console.error("Error starting recognition:", err);
      }
    }
  };

  const speak = (text: string) => {
    if ("speechSynthesis" in window) {
      // Cancel any ongoing speech
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);

      utterance.onstart = () => {
        setIsSpeaking(true);
        setupAudioAnalyzer();
      };

      utterance.onend = () => {
        setIsSpeaking(false);
        cleanupAudioAnalyzer();
      };

      utterance.onerror = () => {
        setIsSpeaking(false);
        cleanupAudioAnalyzer();
      };

      window.speechSynthesis.speak(utterance);
    } else {
      alert(
        "Speech synthesis is not supported in your browser.",
      );
    }
  };

  const setupAudioAnalyzer = () => {
    // Note: Web Speech API doesn't provide direct access to audio analysis
    // We'll simulate audio intensity based on speaking state
    // For real audio analysis, you'd need to capture microphone input
  };

  const cleanupAudioAnalyzer = () => {
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    audioAnalyzerRef.current = null;
  };

  const handleSpeak = () => {
    speak("Hello, I'm a TATA sales assistant to help you out!");
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-8 p-8">
      {/* Gradient Mesh Canvas */}
      <div className="relative">
        <canvas
          ref={canvasRef}
          width={320}
          height={320}
          className="rounded-full"
          style={{
            filter: "blur(0px)",
          }}
        />

        {/* Status indicator */}
        <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex gap-2 items-center">
          {isListening && (
            <span className="text-sm text-blue-400 flex items-center gap-2">
              <span className="inline-block w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
              Listening...
            </span>
          )}
          {isSpeaking && (
            <span className="text-sm text-purple-400 flex items-center gap-2">
              <span className="inline-block w-2 h-2 bg-purple-400 rounded-full animate-pulse" />
              Speaking...
            </span>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="flex gap-4">
        <Button
          onClick={toggleListening}
          size="lg"
          variant={isListening ? "destructive" : "default"}
          className="gap-2"
        >
          {isListening ? (
            <MicOff className="w-5 h-5" />
          ) : (
            <Mic className="w-5 h-5" />
          )}
          {isListening ? "Stop Listening" : "Start Listening"}
        </Button>

        <Button
          onClick={handleSpeak}
          size="lg"
          variant="secondary"
          className="gap-2"
          disabled={isSpeaking}
        >
          <Volume2 className="w-5 h-5" />
          Speak
        </Button>
      </div>

      {/* Transcript Display */}
      {transcript && (
        <div className="max-w-md w-full p-4 bg-slate-800 rounded-lg">
          <p className="text-sm text-slate-400 mb-2">
            You said:
          </p>
          <p className="text-white">{transcript}</p>
        </div>
      )}

      {/* Error Display */}
      {error && (
        <div className="max-w-md w-full p-4 bg-red-800 rounded-lg">
          <p className="text-sm text-red-400 mb-2">Error:</p>
          <p className="text-white">{error}</p>
        </div>
      )}

      {/* Color Guide */}
      <div className="text-center text-sm text-slate-400 mt-8">
        <p className="mb-2">
          💡 To change colors, edit the COLORS object in
          VoiceAssistant.tsx
        </p>
        <div className="flex gap-2 justify-center">
          <div className="flex items-center gap-1">
            <div
              className="w-4 h-4 rounded"
              style={{ backgroundColor: COLORS.primary }}
            />
            <span>Primary</span>
          </div>
          <div className="flex items-center gap-1">
            <div
              className="w-4 h-4 rounded"
              style={{ backgroundColor: COLORS.secondary }}
            />
            <span>Secondary</span>
          </div>
          <div className="flex items-center gap-1">
            <div
              className="w-4 h-4 rounded"
              style={{ backgroundColor: COLORS.accent }}
            />
            <span>Accent</span>
          </div>
          <div className="flex items-center gap-1">
            <div
              className="w-4 h-4 rounded"
              style={{ backgroundColor: COLORS.highlight }}
            />
            <span>Highlight</span>
          </div>
        </div>
      </div>
    </div>
  );
}