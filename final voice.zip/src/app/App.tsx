import { VoiceAssistant } from './components/VoiceAssistant';

export default function App() {
  return (
    <div className="size-full bg-black">
      <VoiceAssistant />
    </div>
  );
}
